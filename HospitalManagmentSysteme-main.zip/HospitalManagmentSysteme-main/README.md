# HospitalManagmentSysteme
Hospital management system project in java using JSP, servlet, JSON, and eclipse. Its using java as core technology and Json file as backend to manage the data records. The application is following the MVC architecture with maven tool. HMS is a Dynamic web application which  help doctors to  Manage the records of patients, adding Labsresults, and track all Labsresults  . It helps patient to know all updates about thier Labresult 

There will be Three main Actors or Users of the application
-doctor
-patient
User can register at platform but the default role is patient.

user redirect to dashboard by role so doctor redirect to doctor dashboard, and patient redirect to patient dashboard
## Modules
### Doctor
The doctor can search about patient by name.

The doctor can VIEW the patient list.

The doctor can add/view/update/delete LabResult for patients

The doctor can delete patients
## Patient
The patient can edit profile and modify personal information

The patient can view all his Labresults wich added by doctor 
## Technology
Technology used in the Hospital Management System project in java

Front -End Jsp, Html, CSS, JS.

Server-side: Servlet.

Back-end: JSON.

Server: Tomcat 9.

## System requirements
Server: Tomcat 9.

JAVA :17 OR ABOVE.

Eclipse EE .
## Installation:
Place The project at Eclipse wokplace 

Open Eclipse platform.

from menu select file-> open project then select the project.

click run maven after finish click run on server then select Server: Tomcat 9.
